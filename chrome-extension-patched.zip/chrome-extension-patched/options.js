import { deriveRelayToken } from './background-utils.js'
import { classifyRelayCheckException, classifyRelayCheckResponse } from './options-validation.js'

const DEFAULT_PORT = 18792

function clampPort(value) {
  const n = Number.parseInt(String(value || ''), 10)
  if (!Number.isFinite(n)) return DEFAULT_PORT
  if (n <= 0 || n > 65535) return DEFAULT_PORT
  return n
}

function updateRelayUrl(port) {
  const el = document.getElementById('relay-url')
  if (!el) return
  el.textContent = `http://127.0.0.1:${port}/`
}

function setStatus(kind, message) {
  const status = document.getElementById('status')
  if (!status) return
  status.dataset.kind = kind || ''
  status.textContent = message || ''
}

async function checkRelayReachable(port, token) {
  const trimmedToken = String(token || '').trim()
  if (!trimmedToken) {
    setStatus('error', 'Gateway token required. Save your gateway token to connect.')
    return
  }
  // Check for custom relay URL
  const stored = await chrome.storage.local.get(['relayUrl'])
  const customUrl = String(stored.relayUrl || '').trim()
  const baseUrl = customUrl ? customUrl.replace(/\/+$/, '') : `http://127.0.0.1:${port}`
  const url = `${baseUrl}/json/version`
  try {
    const relayToken = await deriveRelayToken(trimmedToken, port)
    // Delegate the fetch to the background service worker to bypass
    // CORS preflight on the custom x-openclaw-relay-token header.
    const res = await chrome.runtime.sendMessage({
      type: 'relayCheck',
      url,
      token: relayToken,
    })
    const result = classifyRelayCheckResponse(res, port)
    if (result.action === 'throw') throw new Error(result.error)
    // Override message with actual URL
    if (result.kind === 'ok') {
      result.message = `Relay reachable and authenticated at ${baseUrl}/`
    }
    setStatus(result.kind, result.message)
  } catch (err) {
    const result = classifyRelayCheckException(err, port)
    result.message = `Relay not reachable/authenticated at ${baseUrl}/. Verify relay is running and token is correct.`
    setStatus(result.kind, result.message)
  }
}

async function load() {
  const stored = await chrome.storage.local.get(['relayPort', 'gatewayToken', 'relayUrl'])
  const port = clampPort(stored.relayPort)
  const token = String(stored.gatewayToken || '').trim()
  const relayUrlVal = String(stored.relayUrl || '').trim()
  document.getElementById('port').value = String(port)
  document.getElementById('token').value = token
  const relayUrlInput = document.getElementById('relay-url-input')
  if (relayUrlInput) relayUrlInput.value = relayUrlVal
  updateRelayUrl(port)
  await checkRelayReachable(port, token)
}

async function save() {
  const portInput = document.getElementById('port')
  const tokenInput = document.getElementById('token')
  const relayUrlInput = document.getElementById('relay-url-input')
  const port = clampPort(portInput.value)
  const token = String(tokenInput.value || '').trim()
  const relayUrlVal = String(relayUrlInput?.value || '').trim()
  await chrome.storage.local.set({ relayPort: port, gatewayToken: token, relayUrl: relayUrlVal })
  portInput.value = String(port)
  tokenInput.value = token
  updateRelayUrl(port)
  await checkRelayReachable(port, token)
}

document.getElementById('save').addEventListener('click', () => void save())
void load()
